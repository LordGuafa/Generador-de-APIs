from fastapi import HTTPException
from DAO import ClientesDAO
from model import Clientes
from model.Schemas import Clientes as schema

clientes_DAO = ClientesDAO()

#CREATE
def create_Clientes(data: schema):
	try:
		clientes = Clientes(dni=data.dni, nombre=data.nombre, apellido1=data.apellido1, apellido2=data.apellido2, direccion=data.direccion, email=data.email)
		clientes_DAO.create_Clientes(clientes)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#READ ALL
def get_Clientes():
	return clientes_DAO.get_Clientes_list()

#READ BY PRIMARY_KEY
def get_Clientes_cod_cliente(cod_cliente: int) -> Clientes:
	return clientes_DAO.get_Clientes(cod_cliente)

#READ BY UNIQUE_KEY
def get_Clientes_dni(dni: int) -> Clientes:
	return clientes_DAO.get_Clientes_dni(dni)

def get_Clientes_email(email: str) -> Clientes:
	return clientes_DAO.get_Clientes_email(email)

#UPDATE BY PRIMARY_KEY
def update_Clientes(data, cod_cliente):
	try:
		clientes = Clientes(
			cod_cliente=cod_cliente,
			dni=data.dni,
			nombre=data.nombre,
			apellido1=data.apellido1,
			apellido2=data.apellido2,
			direccion=data.direccion,
			email=data.email
		)
		clientes_DAO.update_Clientes(clientes)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#DELETE
def delete_Clientes(data):
	try:
		clientes_DAO.delete_Clientes(data)
		return 'Exitoso'
	except Exception as e:
		return 'Error'
