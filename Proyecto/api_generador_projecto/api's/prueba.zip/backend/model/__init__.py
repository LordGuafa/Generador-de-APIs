from model.Clientes import Clientes
from model.Prestamos import Prestamos
from model.Copias import Copias
from model.Peliculas import Peliculas
