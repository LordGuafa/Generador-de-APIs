
from sqlalchemy import Column, Integer, String, Boolean, Float, LargeBinary
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Clientes(Base):
	__tablename__ = "Clientes"
	cod_cliente= Column(Integer, primary_key=True, autoincrement=True, nullable=False,unique=False)
	dni= Column(Integer, nullable=False, unique=True)
	nombre= Column(String, nullable=False,unique=False)
	apellido1= Column(String, nullable=False,unique=False)
	apellido2= Column(String, nullable=False,unique=False)
	direccion= Column(String, nullable=True,unique=False)
	email= Column(String, nullable=False, unique=True)
