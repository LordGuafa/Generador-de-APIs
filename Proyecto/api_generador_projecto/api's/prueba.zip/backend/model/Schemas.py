
from pydantic import BaseModel

class Clientes(BaseModel):
	dni:int
	nombre:str
	apellido1:str
	apellido2:str
	direccion:str
	email:str
class Prestamos(BaseModel):
	fecha_pretamo:str
	fecha_tope:str
	fecha_entrega:str
	cod_cliente:int
	n_copia:int
class Copias(BaseModel):
	deteriorada:bool
	formato:str
	id_pelicula:int
	precio_alquiler:int
class Peliculas(BaseModel):
	titulo:str
	ano:int
	critica:str
	caratula:str
