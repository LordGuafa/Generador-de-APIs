
from sqlalchemy import Column, Integer, String, Boolean, Float, LargeBinary
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Prestamos(Base):
	__tablename__ = "Prestamos"
	id_prestamo= Column(Integer, primary_key=True, autoincrement=True, nullable=False,unique=False)
	fecha_pretamo= Column(String, nullable=False,unique=False)
	fecha_tope= Column(String, nullable=False,unique=False)
	fecha_entrega= Column(String, nullable=True,unique=False)
	cod_cliente= Column(Integer, nullable=False,unique=False)
	n_copia= Column(Integer, nullable=False,unique=False)
