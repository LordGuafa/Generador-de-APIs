
from fastapi import APIRouter
from model.Schemas import Copias
from controller import Copias_controller as controller

Copias_routes = APIRouter()

#CREATE
@Copias_routes.post("/create_Copias")
def create_Copias(request: Copias):
	return controller.create_Copias(request)

#READ ALL
@Copias_routes.get("/read_Copias")
def get_Copias_list():
	return controller.get_Copias()

#READ ALL BY PRIMARY_KEY
@Copias_routes.get("/read_Copias/{n_copia}")
def get_Copias(n_copia: int):
	return controller.get_Copias_n_copia(n_copia)

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
@Copias_routes.put("/update_Copias/{n_copia}")
def update_Copias(request: Copias, n_copia: int):
	return controller.update_Copias(request, n_copia)

#DELETE BY PRIMARY_KEY
@Copias_routes.delete("/delete_Copias/{n_copia}")
def delete_Copias(n_copia: int):
	return controller.delete_Copias(n_copia)

