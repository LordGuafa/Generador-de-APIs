
from fastapi import APIRouter
from model.Schemas import Clientes
from controller import Clientes_controller as controller

Clientes_routes = APIRouter()

#CREATE
@Clientes_routes.post("/create_Clientes")
def create_Clientes(request: Clientes):
	return controller.create_Clientes(request)

#READ ALL
@Clientes_routes.get("/read_Clientes")
def get_Clientes_list():
	return controller.get_Clientes()

#READ ALL BY PRIMARY_KEY
@Clientes_routes.get("/read_Clientes/{cod_cliente}")
def get_Clientes(cod_cliente: int):
	return controller.get_Clientes_cod_cliente(cod_cliente)

#READ BY UNIQUE_KEY
@Clientes_routes.get("/read_Clientes_dni/{dni}")
def get_Clientes_dni(dni: int):
	return controller.get_Clientes_dni(dni)

@Clientes_routes.get("/read_Clientes_email/{email}")
def get_Clientes_email(email: str):
	return controller.get_Clientes_email(email)

#UPDATE BY PRIMARY_KEY
@Clientes_routes.put("/update_Clientes/{cod_cliente}")
def update_Clientes(request: Clientes, cod_cliente: int):
	return controller.update_Clientes(request, cod_cliente)

#DELETE BY PRIMARY_KEY
@Clientes_routes.delete("/delete_Clientes/{cod_cliente}")
def delete_Clientes(cod_cliente: int):
	return controller.delete_Clientes(cod_cliente)

