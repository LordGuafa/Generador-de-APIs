
from fastapi import APIRouter
from model.Schemas import Peliculas
from controller import Peliculas_controller as controller

Peliculas_routes = APIRouter()

#CREATE
@Peliculas_routes.post("/create_Peliculas")
def create_Peliculas(request: Peliculas):
	return controller.create_Peliculas(request)

#READ ALL
@Peliculas_routes.get("/read_Peliculas")
def get_Peliculas_list():
	return controller.get_Peliculas()

#READ ALL BY PRIMARY_KEY
@Peliculas_routes.get("/read_Peliculas/{id_pelicula}")
def get_Peliculas(id_pelicula: int):
	return controller.get_Peliculas_id_pelicula(id_pelicula)

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
@Peliculas_routes.put("/update_Peliculas/{id_pelicula}")
def update_Peliculas(request: Peliculas, id_pelicula: int):
	return controller.update_Peliculas(request, id_pelicula)

#DELETE BY PRIMARY_KEY
@Peliculas_routes.delete("/delete_Peliculas/{id_pelicula}")
def delete_Peliculas(id_pelicula: int):
	return controller.delete_Peliculas(id_pelicula)

