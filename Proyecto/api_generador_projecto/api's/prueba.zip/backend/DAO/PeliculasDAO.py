
from typing import List
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from DAO.Connection import BaseDAO
from model.Peliculas import Peliculas

class PeliculasDAO(BaseDAO):
#CREATE
	def create_Peliculas(self, peliculas: Peliculas):
		try:
			self.db.add(peliculas)
			self.commit()
			self.db.refresh(peliculas)
		except IntegrityError:
			self.db.rollback()
			if self.db.query(Peliculas).filter(Peliculas.id_pelicula == peliculas.id_pelicula).first():
				raise HTTPException(status_code=400, detail="id_pelicula already registered")
			return Peliculas

#READ ALL
	def get_Peliculas_list(self) -> List[Peliculas]:
		return self.db.query(Peliculas).all()

#READ BY PRIMARY_KEY
	def get_Peliculas(self, id_pelicula: int) -> Peliculas:
		return self.db.query(Peliculas).filter(Peliculas.id_pelicula == id_pelicula).first()

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
	def update_Peliculas(self, peliculas: Peliculas) -> Peliculas:
		try:
			existing_peliculas = self.db.query(Peliculas).filter(Peliculas.id_pelicula == peliculas.id_pelicula).first()
			if not existing_peliculas:
				raise HTTPException(status_code=404, detail="Peliculas no encontrado")
			for key, value in peliculas.__dict__.items():
				if key != '_sa_instance_state':
					setattr(existing_peliculas, key, value)
			self.db.commit()
			self.db.refresh(existing_peliculas)
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al actualizar Peliculas")
		return existing_peliculas
#DELETE
	def delete_Peliculas(self, id_pelicula: int):
		try:
			data = self.get_Peliculas(id_pelicula)
			self.db.delete(data)
			self.commit()
			return True
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al eliminar Peliculas")

